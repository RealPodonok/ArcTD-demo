// Основной JS файл игры
console.log('ArcTD demo game started');